#############
  procfile
#############

Description
===========

This project is a Python implementation of a ``Procfile`` parser.  See
`Smartmob RFC 1 -- Procfile
<http://smartmob-rfc.readthedocs.org/en/latest/1-procfile.html>`_.
